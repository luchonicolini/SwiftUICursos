//
//  SmartHomeThermostatApp.swift
//  SmartHomeThermostat
//
//  Created by Dara To on 2022-04-17.
//

import SwiftUI

@main
struct SmartHomeThermostatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
